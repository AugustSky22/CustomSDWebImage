//
//  ZYAppDelegate.h
//  ZYCustomSDWebImage
//
//  Created by 张毛 on 15-9-24.
//  Copyright (c) 2015年 ZM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZYAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
