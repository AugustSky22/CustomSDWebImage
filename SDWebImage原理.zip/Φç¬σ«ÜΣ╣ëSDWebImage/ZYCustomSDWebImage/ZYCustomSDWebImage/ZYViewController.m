//
//  ZYViewController.m
//  ZYCustomSDWebImage
//
//  Created by 张毛 on 15-9-24.
//  Copyright (c) 2015年 ZM. All rights reserved.
//

#import "ZYViewController.h"
#import "UIImageView+WebImageCache.h"
#import "UIButton+WebImageCache.h"

@interface ZYViewController ()

@end

@implementation ZYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    //self.imageView1.image = [UIImage imageNamed:@"1.png"];
    
    //self.imageView2.image = [UIImage imageNamed:@"1.png"];
}
- (IBAction)buttonClick:(id)sender
{
    //用NSData请求数据
    //self.imageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:@"http://image.yourdream.cc/group1/M00/A9/B1/CgAAGlOwcOgEAAAAAAAAAPxWNfQ745.jpg"]]];
    
    [self.imageView1 setImageWithUrlString:@"http://image.yourdream.cc/group2/M00/4C/C4/CgAAHFOwcOYEAAAAAAAAACj0Aeo509.jpg" withPlaceholder:[UIImage imageNamed:@"1.png"]];
    
    [self.imageView2 setImageWithUrlString:@"http://image.yourdream.cc/group1/M00/A9/B1/CgAAGlOwcOgEAAAAAAAAAPxWNfQ745.jpg" withPlaceholder:[UIImage imageNamed:@"1.png"]];
    
    [self.button setImageWithUrlString:@"http://image.yourdream.cc/group2/M00/4C/C4/CgAAHFOwcOQEAAAAAAAAAKHzqlo134.jpg" withPlaceholder:[UIImage imageNamed:@"1.png"]];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_imageView1 release];
    [_imageView2 release];
    [_button release];
    [super dealloc];
}

@end
