//
//  UIButton+WebImageCache.h
//  ZYCustomSDWebImage
//
//  Created by 张毛 on 15-9-24.
//  Copyright (c) 2015年 ZM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZYHttpManager.h"

@interface UIButton (WebImageCache)

//方法一：给一个urlString ， 就可以获取到一张图片
- (void)setImageWithUrlString:(NSString* )urlString;

//方法二：先附一张图片，占位符。然后再去干方法一的事
- (void)setImageWithUrlString:(NSString *)urlString withPlaceholder:(UIImage* )image;
@end
