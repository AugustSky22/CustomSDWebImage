//
//  UIButton+WebImageCache.m
//  ZYCustomSDWebImage
//
//  Created by 张毛 on 15-9-24.
//  Copyright (c) 2015年 ZM. All rights reserved.
//

#import "UIButton+WebImageCache.h"

@implementation UIButton (WebImageCache)
//方法一：给一个urlString ， 就可以获取到一张图片
- (void)setImageWithUrlString:(NSString* )urlString
{
    ZYHttpManager* httpManager = [ZYHttpManager shareHttpManager];
    //如果，内存有，直接从内存中读取
    UIImage* image = [httpManager searchInCacheWithUrlString:urlString];
    if (image) {
        NSLog(@"从内存中来");
        [self setBackgroundImage:image forState:UIControlStateNormal];
        return;
    }
    //如果，内存没有，那么从本地获取
    image = [httpManager searchInLocationWithUrlString:urlString];
    if (image) {
        NSLog(@"从本地来");
        [self setBackgroundImage:image forState:UIControlStateNormal];
        return;
    }
    
    //如果，本地没有，那么从网络请求
    [httpManager requestToImageWithUrlString:urlString completion:^(UIImage *image) {
        NSLog(@"请求来");
        [self setBackgroundImage:image forState:UIControlStateNormal];
    }];
}
//方法二：先附一张图片，占位符。然后再去干方法一的事
- (void)setImageWithUrlString:(NSString *)urlString withPlaceholder:(UIImage* )image
{
    [self setBackgroundImage:image forState:UIControlStateNormal];
    //调用方法一
    [self setImageWithUrlString:urlString];
}
@end
