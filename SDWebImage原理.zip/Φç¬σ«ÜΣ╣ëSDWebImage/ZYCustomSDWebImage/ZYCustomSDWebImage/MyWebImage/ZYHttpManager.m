//
//  ZYHttpManager.m
//  ZYCustomSDWebImage
//
//  Created by 张毛 on 15-9-24.
//  Copyright (c) 2015年 ZM. All rights reserved.
//

#import "ZYHttpManager.h"

static ZYHttpManager* _httpManager = nil;

@implementation ZYHttpManager
//声明一个方法，获取本类的对象（单例类）
+ (ZYHttpManager* )shareHttpManager
{
    @synchronized(self){
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            _httpManager = [[ZYHttpManager alloc] init];
        });
    }
    return _httpManager;
}
//重写初始化，给属性赋值
- (id)init
{
    self = [super init];
    if (self) {
        self.cacheDictionary = [NSMutableDictionary dictionaryWithCapacity:0];
    }
    return self;
}


//SDWebImage实现原理
//内存有,直接从内存读取
- (UIImage* )searchInCacheWithUrlString:(NSString* )urlString
{
    UIImage* image = [self.cacheDictionary objectForKey:urlString];
    return image;
}
//内存没有，从本地读取
- (UIImage* )searchInLocationWithUrlString:(NSString* )urlString
{
    NSString* filePath = [NSString getExistsFilePath:@"Library/Caches/ImageCaches" withFileName:[urlString MD5]];
    UIImage* image = [UIImage imageWithData:[NSData dataWithContentsOfFile:filePath]];
    
    //放一份到内存中
    if (image) {
        [self.cacheDictionary setObject:image forKey:urlString];
    }
    
    return image;
}
//本地没有，从网络中请求
- (void)requestToImageWithUrlString:(NSString* )urlString completion:(void(^)(UIImage* image))completion
{
    //用GCD获取图片
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        //在这发送请求
        NSData* data = [NSData dataWithContentsOfURL:[NSURL URLWithString:urlString]];
        dispatch_async(dispatch_get_main_queue(), ^
        {
            //在这刷新UI
            UIImage* image = [UIImage imageWithData:data];
            if (image)
            {
                //要把图片显示出来
                if (completion) {
                    //判断block实现了没有
                    completion(image);
                }
                
                //放到内存中
                [self.cacheDictionary setObject:image forKey:urlString];
                
                //放到本地
                NSString* filePath = [NSString getExistsFilePath:@"Library/Caches/ImageCaches" withFileName:[urlString MD5]];
                [data writeToFile:filePath atomically:YES];
            }
        });
    });
}
@end
