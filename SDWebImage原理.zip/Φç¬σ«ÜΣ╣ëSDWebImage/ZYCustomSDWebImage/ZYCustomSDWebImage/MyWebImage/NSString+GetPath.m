//
//  NSString+GetPath.m
//  ASIDownLoad
//
//  Created by 张毛 on 15-9-16.
//  Copyright (c) 2015年 ZM. All rights reserved.
//

#import "NSString+GetPath.h"

@implementation NSString (GetPath)
//获取路径
+ (NSString* )getFilePath:(NSString* )path
{
    return [NSHomeDirectory() stringByAppendingPathComponent:path];
}

//得到一个确切存在的文件路径
+ (NSString* )getExistsFilePath:(NSString* )path
{
    NSString* filePath = [self getFilePath:path];
    if (![[NSFileManager defaultManager] fileExistsAtPath:filePath])
    {
        //文件夹不存在，创建
        if ([[NSFileManager defaultManager] createDirectoryAtPath:filePath withIntermediateDirectories:YES attributes:nil error:nil])
        {
            NSLog(@"创建成功");
        }else
        {
            NSLog(@"创建失败");
        }
    }else
    {
        NSLog(@"文件夹已存在");
    }
    return filePath;
}
//得到一个确切存在的文件路径和拼接好的文件名（文件可以不存在）
+ (NSString* )getExistsFilePath:(NSString *)path withFileName:(NSString* )name
{
    NSString* filePath = [self getExistsFilePath:path];
    filePath = [filePath stringByAppendingPathComponent:name];
    return filePath;
}
@end
