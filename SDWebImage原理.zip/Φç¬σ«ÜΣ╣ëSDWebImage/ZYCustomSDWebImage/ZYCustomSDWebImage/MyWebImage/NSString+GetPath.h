//
//  NSString+GetPath.h
//  ASIDownLoad
//
//  Created by 张毛 on 15-9-16.
//  Copyright (c) 2015年 ZM. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (GetPath)

//获取路径
+ (NSString* )getFilePath:(NSString* )path;
//得到一个确切存在的文件路径
+ (NSString* )getExistsFilePath:(NSString* )path;
//得到一个确切存在的文件路径和拼接好的文件名（文件可以不存在）
+ (NSString* )getExistsFilePath:(NSString *)path withFileName:(NSString* )name;
@end
