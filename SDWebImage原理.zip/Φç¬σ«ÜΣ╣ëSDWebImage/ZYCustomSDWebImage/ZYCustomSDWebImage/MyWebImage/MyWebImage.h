//
//  MyWebImage.h
//  ZYCustomSDWebImage
//
//  Created by 张毛 on 15-9-24.
//  Copyright (c) 2015年 ZM. All rights reserved.
//

#ifndef ZYCustomSDWebImage_MyWebImage_h
#define ZYCustomSDWebImage_MyWebImage_h


#import "UIImageView+WebImageCache.h"
#import "UIButton+WebImageCache.h"
#endif
