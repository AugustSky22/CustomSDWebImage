//
//  ZYHttpManager.h
//  ZYCustomSDWebImage
//
//  Created by 张毛 on 15-9-24.
//  Copyright (c) 2015年 ZM. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSString+GetPath.h"
#import "NSString+MD5.h"

@interface ZYHttpManager : NSObject

//这个字典就是我们之前说的（内存有，去内存找）。这个字典就是内存。存放的是已经请求过(本地的，从网络直接请求的)的图片。
@property(nonatomic,retain)NSMutableDictionary* cacheDictionary;
//声明一个方法，获取本类的对象（单例类）
+ (ZYHttpManager* )shareHttpManager;


//SDWebImage实现原理
//内存有,直接从内存读取
- (UIImage* )searchInCacheWithUrlString:(NSString* )urlString;
//内存没有，从本地读取
- (UIImage* )searchInLocationWithUrlString:(NSString* )urlString;
//本地没有，从网络中请求
- (void)requestToImageWithUrlString:(NSString* )urlString completion:(void(^)(UIImage* image))completion;
@end
